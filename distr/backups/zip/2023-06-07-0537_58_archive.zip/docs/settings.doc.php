<?php exit; ?>
Settings API

CHECKUPDATES
-checkbox
-$checkupdates
-i18n('CHECK_UPDATES')
