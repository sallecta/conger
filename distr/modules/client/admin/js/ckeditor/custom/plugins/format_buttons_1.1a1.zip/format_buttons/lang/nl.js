/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'format_buttons', 'nl', {
  h1: 'Hoofding 1',
  h2: 'Hoofding 2',
  h3: 'Hoofding 3',
  h4: 'Hoofding 4',
  h5: 'Hoofding 5',
  h6: 'Hoofding 6',
} );
