<?php 
// Getsimple no index allowed 
?>