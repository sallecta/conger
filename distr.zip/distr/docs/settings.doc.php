<?php exit; ?>
Settings API

CHECKUPDATES
-checkbox
-$checkupdates
-i18n('CHECK_UPDATES')

PAGE_TIME_STAMP
-checkbox
-$page_time_stamp
-i18n('PAGE_TIME_STAMP')
