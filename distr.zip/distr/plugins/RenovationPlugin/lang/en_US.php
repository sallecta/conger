<?php
 
$i18n = array (
	
	"RENOVATION_TITLE"	=>	"Renovation Theme Settings",
	"RENOVATION_DESC"	=>	"Settings for the default GetSimple theme: Renovation",
	"FACEBOOK_ERROR"	=>	"Facebook URL is not valid.",
	"GOOGLEPLUS_ERROR"	=>	"Goolge Plus URL is not valid.",
	"TWITTER_ERROR"		=>	"Twitter URL is not valid.",
	"LINKEDIN_ERROR"	=>	"LinkedIn URL is not valid.",
	"TUMBLR_ERROR"		=>	"Tumblr URL is not valid.",
	"INSTAGRAM_ERROR"	=>	"Instagram URL is not valid.",
	"YOUTUBE_ERROR"		=>	"Youtube URL is not valid.",
	"VIMEO_ERROR"		=>	"Vimeo URL is not valid.",
	"GITHUB_ERROR"		=>	"Github URL is not valid.",
	"FACEBOOK_URL"		=>	"Facebook URL",
	"GOOGLEPLUS_URL"	=>	"Google Plus URL",
	"TWITTER_URL"		=>	"Twitter URL",
	"LINKEDIN_URL"		=>	"LinkedIn URL",
	"TUMBLR_URL"		=>	"Tumblr URL",
	"INSTAGRAM_URL"		=>	"Instagram URL",
	"YOUTUBE_URL"		=>	"Youtube URL",
	"VIMEO_URL"			=>	"Vimeo URL",
	"GITHUB_URL"		=>	"Github URL"

);
