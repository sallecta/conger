<?php
 
$i18n = array
(
	"EDIT_PAGE"	=>	"Edit this page"
);
