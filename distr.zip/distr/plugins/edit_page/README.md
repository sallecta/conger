Edit Page 
==============

A very simple plugin for the Conger CMS which does nothing, but adding an "Edit this page" 
link below every page's content area, whenever the user is logged in to the admin backend.

As it does not rely on the GSCOOKIEISSITEWIDE configuration it works on Conger installations with a version >= 3.1.
